# Nome do Projeto
Assistente de Tarefas Pessoais com IA

## Objetivo
Criar um assistente baseado em IA que ajuda o usuário a organizar suas tarefas diárias,
priorizando prazos e importância, usando prompts otimizados.

## Prompt Principal
"Você é um assistente de produtividade. Receba as tarefas listadas pelo usuário e crie uma lista
organizada por prioridade e urgência. Retorne no formato:
1. [Tarefa] – prioridade (alta/média/baixa) – prazo sugerido."

## Exemplo de Entrada
- Comprar materiais de construção
- Renovar seguro do carro
- Estudar IA 1 hora por noite
- Ligar para fornecedor

## Exemplo de Saída
1. Renovar seguro do carro – Alta – até amanhã
2. Estudar IA 1h por noite – Média – rotina diária
3. Ligar para fornecedor – Média – até sexta
4. Comprar materiais de construção – Baixa – até domingo

## Tecnologias / Ferramentas
- ChatGPT (GPT-4 ou GPT-5)
- Google Sheets (para salvar tarefas, opcional)
- Zapier (para automação futura)

## Resultados
O sistema classifica tarefas automaticamente e reduz tempo de planejamento diário.

## Próximos Passos
Integrar com o Google Calendar ou Notion.
